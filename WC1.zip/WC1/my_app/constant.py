USER_ROLE = (
    ('admin', 'admin'),
    ('user', 'user'),
)