from django.shortcuts import render, redirect
from django.http import HttpResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from my_app.client_microservice import send_data
from my_app.models import UserModel
import requests

from django.contrib.sessions.models import Session
from django.contrib.auth import get_user_model
from django.contrib.sessions.backends.db import SessionStore
from django.contrib.auth import login, authenticate, logout

from my_app.forms import LoginForm

import logging
import logging.config
from django.conf import settings

# Apply Django's logging config
logging.config.dictConfig(settings.LOGGING)

logger = logging.getLogger('custom_logger')

# # Create your views here.

def websocket_view(request):
    try:
        return render(request, 'my_app/authentication/websocket_data.html')
    
    except Exception as e:
        logger.error(f"Error in websocket_view: {e}")


def login_page(request):
    form = LoginForm()
    message = ''
    user = ''

    if request.method == 'GET':
        logout(request)

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password'],
            )
            if user is not None:
                login(request, user)
                message = f'Hello {user.username}! You have been logged in'
                user = user
        
                
                # return redirect('websocket_data') 
            else:
                message = 'Login failed!'
    return render(
        request, 'my_app/authentication/login.html', context={'form': form, 'message': user})




@api_view(['GET'])
def user_data_consumer(request):
    try:
        url = request.query_params.get('url')
        if not url:
            return Response({'error': 'URL parameter is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Call the client microservice to get data
        data = send_data(url)
        # print(data)

        if not data:
            return Response({'error': 'No data found'}, status=status.HTTP_404_NOT_FOUND)

        user_role = UserModel.objects.all().values_list('role', flat=True).distinct()
        if not user_role:
            return Response({'error': 'No roles found'}, status=status.HTTP_404_NOT_FOUND)
        
        response_date = {
            'data': data,
            'roles': list(user_role)
        }

        # print(response_date)

        return Response(response_date, status=status.HTTP_200_OK)

    except Exception as e:
        logger.error(f"Error in user_data_consumer: {e}", exc_info=True)
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)



User = get_user_model()

@api_view(['GET'])
def create_session_for_user(request):
    try:
        username = request.query_params.get('username')

        if not username:
            return Response({'error': 'Username parameter is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        user = User.objects.get(username=username)

        if not user:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        
        # Create a new session
        session = SessionStore()
        session.create()
        
        # Simulate login by setting user ID and auth backend
        session['_auth_user_id'] = user.id
        session['_auth_user_backend'] = 'django.contrib.auth.backends.ModelBackend'
        session['_auth_user_hash'] = user.get_session_auth_hash()
        
        # Save session to the database
        session.save()

        response_data = session.session_key

        print("Session created successfully. Session key:", response_data)

        return Response({'session_key': response_data}, status=status.HTTP_200_OK)

    except User.DoesNotExist:
        print("User not found.")
        return None


@api_view(['GET'])
def get_user_ip(request):
    ip_address = request.META.get('HTTP_X_FORWARDED_FOR')
    if ip_address:
        ip_address = ip_address.split(',')[0]
        print(f"IP Address---------------150: {ip_address}")

    else:
        ip_address = request.META.get('REMOTE_ADDR')
        print(f"IP Address---------------200: {ip_address}")
    return HttpResponse(f'Your IP address is: {ip_address}')