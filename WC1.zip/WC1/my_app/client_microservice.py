import requests
import json


def send_data(url):

    api_response = requests.get(url)
    if api_response.status_code == 200:
        data = api_response.json()

        data = data['data']
        
        json_data = json.dumps(data)

        return json_data
        
    else:
        print(f"Failed to fetch data from API: {api_response.status_code}")



