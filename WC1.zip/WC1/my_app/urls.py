from django.urls import path
from my_app import views


urlpatterns = [
    path('user_data/', views.user_data_consumer, name='user_data_consumer'),
    path('user_session/', views.create_session_for_user, name='create_session_for_user'),
    path('login/', views.login_page, name='login'),
    path('websocket_data/', views.websocket_view, name='websocket_data'),
    path('get_user_ip/', views.get_user_ip, name='get_user_ip'),
]