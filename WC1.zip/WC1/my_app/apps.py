from django.apps import AppConfig

import logging
logger = logging.getLogger('custom_logger')

class MyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'my_app'
