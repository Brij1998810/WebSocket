from channels.consumer import AsyncConsumer, SyncConsumer
from channels.exceptions import StopConsumer
import time
import requests
import json
import asyncio
import aiohttp

import logging
import logging.config
from django.conf import settings

# Apply Django's logging config
logging.config.dictConfig(settings.LOGGING)

logger = logging.getLogger('custom_logger')

# The SyncConsumer class is used for handling synchronous WebSocket connections.

# class MySyncConsumer(SyncConsumer):

#     def websocket_connect(self, event):
#         # Handle WebSocket connection
#         print(f"WebSocket connected....{event}")
#         self.send({
#             "type": "websocket.accept"
#         })

    
#     def websocket_receive(self, event):
#         # Handle WebSocket message
#         print(f"WebSocket message received....{event}")
#         print(event['text'])

#         api_response = requests.get('https://fakestoreapiserver.reactbd.com/smart')
#         if api_response.status_code == 200:
#             data = api_response.json()
            
#             for item in data:
#                 json_data = json.dumps(item)
#                 # print(json_data)
#                 self.send({
#                     "type": "websocket.send",
#                     "text": json_data
#                 })

#                 time.sleep(1)
            
#             print(f"WebSocket Message Successfully sent....{event}")

#         else:
#             print(f"Failed to fetch data from API: {api_response.status_code}")

#     def websocket_disconnect(self, event):
#         # Handle WebSocket disconnection
#         print(f"WebSocket disconnected....{event}")
#         raise StopConsumer()
    


# The AsyncConsumer class is used for handling asynchronous WebSocket connections.  

class MyAsyncConsumer(AsyncConsumer):

    async def websocket_connect(self, event):
        # Handle WebSocket connection
        print(f"WebSocket connected....{event}")
        await self.send({
            "type": "websocket.accept"
        })

    async def websocket_receive(self, event):
        print(f"WebSocket message received....{event}")
        print(event['text'])

        # Step 1: Check if "user" role exists via API
        params = {
            'url': "https://fakerapi.it/api/v1/persons?_quantity=10000"
        }
        async with aiohttp.ClientSession() as session:
            async with session.get('http://127.0.0.1:8000/api/user_data/', params=params) as role_response:
                if role_response.status == 200:
                    role_data = await role_response.json()
                    roles = role_data.get("roles", [])
                    data = role_data.get("data", [])
                    
                    
                    # Convert data from string to list
                    if isinstance(data, str):
                        data = json.loads(data)
                        print(f"----------------509: {len(data)}")

                    
                    if "user" not in roles:
                        await self.send({
                            "type": "websocket.send",
                            "text": json.dumps({"error": "No 'user' role found"})
                        })

                        return

         
                    for item in data:
                        json_data = json.dumps(item)
                        await self.send({
                            "type": "websocket.send",
                            "text": json_data
                        })
                        await asyncio.sleep(1)
                else:
                    await self.send({
                        "type": "websocket.send",
                        "text": json.dumps({"error": "Failed to fetch roles"})
                    })

    async def websocket_disconnect(self, event):
        # Handle WebSocket disconnection
        print(f"WebSocket disconnected....{event}")
        raise StopConsumer()





from channels.generic.websocket import AsyncWebsocketConsumer
from django.contrib.sessions.models import Session
import json
from django.contrib.auth import get_user_model
from asgiref.sync import async_to_sync
from asgiref.sync import sync_to_async





User = get_user_model()

class MyAsyncConsumerWebsocket(AsyncWebsocketConsumer):
    async def websocket_connect(self, event):
        print(f"-----------------------100: {event}")
        # session_key = "tacxxneq19erq4az672vzrncyiv4xqi2"
        try:
            # # # Get session and user using sync_to_async
            # session = await sync_to_async(Session.objects.get)(session_key=session_key)
            # session_data = session.get_decoded()
            # uid = session_data.get('_auth_user_id')
            # user = await sync_to_async(User.objects.get)(id=uid)

            # print(f"----------------150: {user}")
            user = self.scope["user"]
            print(f"-----------------------150: {self.scope['user'].username}")
            logger.error(f"-----------------------150: {self.scope['user'].username}")
            if user.is_authenticated:
                # self.group_name = f"user_{user.id}"
                self.group_name = "User"
                await self.channel_layer.group_add(self.group_name, self.channel_name)
                await self.accept()
                print(f"Connected and added to group: {self.group_name}")
            else:
                await self.close()

        except Exception as e:
            logger.error(f"Error in websocket_connect: {e}", exc_info=True)
            await self.close()



    async def websocket_receive(self, event):
        try:
            print(f"-----------------------210: {event}")
            await self.send(text_data=json.dumps({
                "message": event["text"]
            }))
        
        except Exception as e:
            logger.error(f"Error in websocket_receive: {e}", exc_info=True)



   
    async def websocket_message(self, event):
        try:
            print(f"-----------------------280: {event}")
            await self.send(text_data=json.dumps({
                "message": event["message"]
            }))
        except Exception as e:
            logger.error(f"Error in websocket_message: {e}", exc_info=True)





    async def websocket_disconnect(self, event):
        try:
            print(f"WebSocket disconnected....{event}")
            if hasattr(self, 'group_name'):
                await self.channel_layer.group_discard(self.group_name, self.channel_name)
                print(f"Disconnected from group: {self.group_name}")

            raise StopConsumer()
            
        except Exception as e:
            logger.error(f"Error in websocket_disconnect: {e}", exc_info=True)
            raise StopConsumer()